/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.projetokhaled.business.interfaces;

import br.com.projetokhaled.dominio.Tabacaria;
import java.util.List;

/**
 *
 * @author internet
 */
public interface TabacariaInterface {
     public Tabacaria TabacariaFornecedor(Tabacaria tabacaria);
    
    public Tabacaria buscarTabacariaPorRegiao(String regiao_sp);
    
}
